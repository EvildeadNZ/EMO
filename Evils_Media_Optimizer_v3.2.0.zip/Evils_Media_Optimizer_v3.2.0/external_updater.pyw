from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
import traceback
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk


PRESERVE_FILES = {
    "config.json",
    "history.json",
    "evils_media_optimizer.log",
}

PRESERVE_DIRS = {
    "cache",
    "_updates",
    "__pycache__",
}

MAX_BACKUPS = 5


def wait_for_process(pid: int, timeout: int = 60) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if os.name == "nt":
            result = subprocess.run(
                [
                    "tasklist",
                    "/FI",
                    f"PID eq {pid}",
                    "/NH",
                ],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW,
                check=False,
            )
            if str(pid) not in result.stdout:
                return
        else:
            try:
                os.kill(pid, 0)
            except OSError:
                return
        time.sleep(0.5)

    raise RuntimeError(
        "Evil's Media Optimizer did not close within 60 seconds."
    )


def find_package_root(extracted: Path) -> Path:
    candidates = [
        app.parent
        for app in extracted.rglob("app.py")
        if (app.parent / "version.py").exists()
    ]
    if len(candidates) != 1:
        raise RuntimeError(
            "The update package does not contain one valid app folder."
        )
    return candidates[0]


def backup_application(
    app_dir: Path,
    old_version: str,
) -> Path:
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    backup = (
        app_dir
        / "_updates"
        / "backups"
        / f"{old_version}-{timestamp}"
    )
    backup.mkdir(parents=True, exist_ok=False)

    for item in app_dir.iterdir():
        if item.name in PRESERVE_FILES:
            continue
        if item.name in PRESERVE_DIRS:
            continue

        target = backup / item.name
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)

    return backup


def clean_old_backups(app_dir: Path) -> None:
    backup_root = app_dir / "_updates" / "backups"
    if not backup_root.exists():
        return

    backups = sorted(
        [item for item in backup_root.iterdir() if item.is_dir()],
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for old in backups[MAX_BACKUPS:]:
        shutil.rmtree(old, ignore_errors=True)


def copy_update(package_root: Path, app_dir: Path) -> None:
    for item in package_root.iterdir():
        if item.name in PRESERVE_FILES:
            continue
        if item.name in PRESERVE_DIRS:
            continue

        destination = app_dir / item.name
        if item.is_dir():
            if destination.exists():
                shutil.rmtree(destination)
            shutil.copytree(item, destination)
        else:
            shutil.copy2(item, destination)


def restore_backup(backup: Path, app_dir: Path) -> None:
    for item in app_dir.iterdir():
        if item.name in PRESERVE_FILES:
            continue
        if item.name in PRESERVE_DIRS:
            continue

        if item.is_dir():
            shutil.rmtree(item, ignore_errors=True)
        else:
            try:
                item.unlink()
            except OSError:
                pass

    for item in backup.iterdir():
        destination = app_dir / item.name
        if item.is_dir():
            shutil.copytree(item, destination)
        else:
            shutil.copy2(item, destination)


def launch_app(app_dir: Path) -> None:
    pythonw = Path(sys.executable)
    if pythonw.name.lower() == "python.exe":
        candidate = pythonw.with_name("pythonw.exe")
        if candidate.exists():
            pythonw = candidate

    subprocess.Popen(
        [
            str(pythonw),
            str(app_dir / "EvilsMediaOptimizer.pyw"),
        ],
        cwd=str(app_dir),
        creationflags=(
            subprocess.CREATE_NO_WINDOW
            if os.name == "nt"
            else 0
        ),
        close_fds=True,
    )


class UpdaterWindow:
    def __init__(self, args):
        self.args = args
        self.root = tk.Tk()
        self.root.title("Evil's Media Optimizer — Updating")
        self.root.geometry("560x205")
        self.root.resizable(False, False)
        self.root.configure(bg="#0a080d")

        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(
            "Purple.Horizontal.TProgressbar",
            troughcolor="#19121f",
            background="#a23bcc",
            bordercolor="#33203d",
            lightcolor="#a23bcc",
            darkcolor="#a23bcc",
        )

        title = tk.Label(
            self.root,
            text="EVIL'S MEDIA OPTIMIZER",
            bg="#0a080d",
            fg="#d75cff",
            font=("Segoe UI", 17, "bold"),
        )
        title.pack(pady=(18, 4))

        self.status = tk.Label(
            self.root,
            text="Preparing update...",
            bg="#0a080d",
            fg="#eee7f2",
            font=("Segoe UI", 10),
        )
        self.status.pack(pady=(4, 14))

        self.progress = ttk.Progressbar(
            self.root,
            style="Purple.Horizontal.TProgressbar",
            orient="horizontal",
            length=500,
            mode="determinate",
            maximum=100,
        )
        self.progress.pack()

        self.version = tk.Label(
            self.root,
            text=f"{args.old_version}  →  {args.new_version}",
            bg="#0a080d",
            fg="#a99eb0",
            font=("Segoe UI", 9),
        )
        self.version.pack(pady=(12, 0))

        self.root.after(300, self.run_update)

    def set_step(self, value: int, message: str) -> None:
        self.progress["value"] = value
        self.status.configure(text=message)
        self.root.update_idletasks()

    def run_update(self) -> None:
        app_dir = Path(self.args.app_dir).resolve()
        update_zip = Path(self.args.zip).resolve()
        backup = None

        try:
            self.set_step(8, "Waiting for the main app to close...")
            wait_for_process(self.args.pid)

            self.set_step(20, "Extracting update package...")
            with tempfile.TemporaryDirectory(
                prefix="evils-media-install-"
            ) as temporary:
                extracted = Path(temporary)
                with zipfile.ZipFile(update_zip, "r") as archive:
                    archive.extractall(extracted)

                package_root = find_package_root(extracted)

                self.set_step(38, "Creating rollback backup...")
                backup = backup_application(
                    app_dir,
                    self.args.old_version,
                )

                self.set_step(58, "Replacing application files...")
                copy_update(package_root, app_dir)

                self.set_step(78, "Cleaning old backups...")
                clean_old_backups(app_dir)

            self.set_step(92, "Launching updated application...")
            launch_app(app_dir)

            self.set_step(100, "Update complete.")
            self.root.after(1200, self.root.destroy)

        except Exception as exc:
            details = traceback.format_exc()
            try:
                log_path = (
                    app_dir
                    / "_updates"
                    / "last-update-error.log"
                )
                log_path.parent.mkdir(parents=True, exist_ok=True)
                log_path.write_text(details, encoding="utf-8")
            except Exception:
                pass

            if backup is not None and backup.exists():
                try:
                    self.set_step(70, "Update failed — restoring backup...")
                    restore_backup(backup, app_dir)
                    launch_app(app_dir)
                except Exception:
                    pass

            messagebox.showerror(
                "Update failed",
                f"The update failed and the previous version was restored "
                f"where possible.\n\n{exc}\n\n"
                "Details were saved under _updates.",
            )
            self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", required=True)
    parser.add_argument("--app-dir", required=True)
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--old-version", required=True)
    parser.add_argument("--new-version", required=True)
    return parser.parse_args()


if __name__ == "__main__":
    UpdaterWindow(parse_args()).run()

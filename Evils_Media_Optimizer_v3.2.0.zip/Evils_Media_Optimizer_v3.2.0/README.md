# Evil's Media Optimizer 3.2.0

## One-time installation

Because the old updater runs inside the main app and Windows locks its assets,
install 3.2.0 manually into a new folder one final time.

1. Extract this ZIP into a new folder.
2. Copy your existing `config.json`, `history.json`, and `cache` folder from
   v3.0.0 into the new v3.2.0 folder if you want to retain them.
3. Start with `START Evil's Media Optimizer.vbs`.

## Future updates

From 3.2.0 onward:

1. Open Settings → Updates.
2. Choose the newer update ZIP.
3. Confirm.
4. The main app closes.
5. A separate purple update window installs the update.
6. The updated app reopens automatically.

The updater creates a rollback backup, restores it if installation fails, and
keeps the five newest backups.

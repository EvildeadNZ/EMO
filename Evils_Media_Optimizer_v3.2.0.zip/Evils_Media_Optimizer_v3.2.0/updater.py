from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


class UpdateError(RuntimeError):
    pass


def _version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in value.strip().split("."))
    except ValueError as exc:
        raise UpdateError(f"Invalid version number: {value}") from exc


def _find_package_root(extracted: Path) -> Path:
    candidates: list[Path] = []
    for app_file in extracted.rglob("app.py"):
        parent = app_file.parent
        if (
            (parent / "version.py").exists()
            and (parent / "external_updater.pyw").exists()
        ):
            candidates.append(parent)

    if len(candidates) != 1:
        raise UpdateError(
            "The ZIP must contain exactly one valid Evil's Media "
            "Optimizer update folder."
        )
    return candidates[0]


def _read_version(package_root: Path) -> str:
    namespace: dict[str, object] = {}
    try:
        exec(
            (package_root / "version.py").read_text(
                encoding="utf-8"
            ),
            namespace,
        )
    except Exception as exc:
        raise UpdateError(
            f"Could not read the update version: {exc}"
        ) from exc

    value = namespace.get("APP_VERSION")
    if not isinstance(value, str) or not value.strip():
        raise UpdateError("The update has no valid APP_VERSION.")
    return value.strip()


def validate_update_zip(
    update_zip: Path,
    current_version: str,
) -> str:
    update_zip = update_zip.resolve()

    if not update_zip.exists():
        raise UpdateError(f"Update ZIP not found: {update_zip}")
    if update_zip.suffix.lower() != ".zip":
        raise UpdateError("The selected update must be a ZIP file.")
    if not zipfile.is_zipfile(update_zip):
        raise UpdateError("The selected file is not a valid ZIP archive.")

    with tempfile.TemporaryDirectory(
        prefix="evils-media-validate-"
    ) as temporary:
        extracted = Path(temporary)
        try:
            with zipfile.ZipFile(update_zip, "r") as archive:
                archive.extractall(extracted)
        except Exception as exc:
            raise UpdateError(
                f"Could not inspect the update: {exc}"
            ) from exc

        package_root = _find_package_root(extracted)
        new_version = _read_version(package_root)

        if _version_tuple(new_version) <= _version_tuple(
            current_version
        ):
            raise UpdateError(
                f"The package is version {new_version}, while the "
                f"installed version is {current_version}. Choose a "
                "newer package."
            )

        required = {
            "app.py",
            "version.py",
            "updater.py",
            "external_updater.pyw",
            "EvilsMediaOptimizer.pyw",
        }
        missing = sorted(
            name
            for name in required
            if not (package_root / name).exists()
        )
        if missing:
            raise UpdateError(
                "The update package is incomplete. Missing: "
                + ", ".join(missing)
            )

    return new_version


def launch_external_update(
    update_zip: Path,
    app_dir: Path,
    *,
    current_version: str,
    current_pid: int,
) -> str:
    update_zip = update_zip.resolve()
    app_dir = app_dir.resolve()

    new_version = validate_update_zip(
        update_zip,
        current_version,
    )

    runner_source = app_dir / "external_updater.pyw"
    if not runner_source.exists():
        raise UpdateError(
            "The external updater is missing from this installation."
        )

    staging = Path(tempfile.mkdtemp(prefix="evils-media-updater-"))
    runner = staging / "external_updater.pyw"
    shutil.copy2(runner_source, runner)

    pythonw = Path(sys.executable)
    if pythonw.name.lower() == "python.exe":
        candidate = pythonw.with_name("pythonw.exe")
        if candidate.exists():
            pythonw = candidate

    command = [
        str(pythonw),
        str(runner),
        "--zip",
        str(update_zip),
        "--app-dir",
        str(app_dir),
        "--pid",
        str(current_pid),
        "--old-version",
        current_version,
        "--new-version",
        new_version,
    ]

    try:
        subprocess.Popen(
            command,
            cwd=str(staging),
            creationflags=(
                subprocess.CREATE_NO_WINDOW
                if os.name == "nt"
                else 0
            ),
            close_fds=True,
        )
    except Exception as exc:
        raise UpdateError(
            f"Could not launch the separate updater: {exc}"
        ) from exc

    return new_version

# Evil's Media Optimizer 3.1.0

Install through the existing updater:

1. Open Evil's Media Optimizer 3.0.0.
2. Open Settings → Updates.
3. Select this ZIP.
4. Close and reopen the app.

The updater preserves your settings, Jellyfin API key, history, cache and logs.

## New

- Start Process wording.
- Live moving GPU usage and temperature graphs during NVENC encoding.
- Live NAS download graph while copying the source to the PC.
- Live NAS upload graph while copying the result back.
- Telemetry automatically disappears after processing.
- Optional shutdown, sleep, hibernate or restart in Settings → Queue.
- The default is Do nothing.
- A confirmation is required before any enabled power action.

## Dependency

Version 3.1 uses psutil for network telemetry. Run this once if the network
graphs remain at zero because psutil is missing:

    python -m pip install -r requirements.txt

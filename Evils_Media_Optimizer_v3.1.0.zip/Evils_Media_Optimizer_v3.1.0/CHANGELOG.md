# Changelog

## 3.1.0

- Renamed Start Queue to Start Process.
- Added moving GPU usage and GPU temperature graphs.
- Added moving NAS download and upload graphs.
- Live telemetry appears only while processing and then disappears.
- Added optional queue-finish power actions.
- All automatic finish actions default to Do nothing.
- Added confirmation before a power action.
- Added psutil for network telemetry.


## 3.0.0

- Added Settings → Updates.
- Added safe update installation from ZIP.
- Added automatic backup before updating.
- Preserves configuration, history, posters and logs.
- Added version.py as the single source of version information.
- Fixed missing QGridLayout import.
- Retained hidden-console normal launcher.

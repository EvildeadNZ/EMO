# Changelog

## 3.0.0

- Added Settings → Updates.
- Added safe update installation from ZIP.
- Added automatic backup before updating.
- Preserves configuration, history, posters and logs.
- Added version.py as the single source of version information.
- Fixed missing QGridLayout import.
- Retained hidden-console normal launcher.

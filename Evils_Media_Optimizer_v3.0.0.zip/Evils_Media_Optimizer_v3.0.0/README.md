# Evil's Media Optimizer 3.0.0

## Normal start

Double-click:

    START Evil's Media Optimizer.vbs

No Command Prompt window stays open. Use the troubleshooting BAT only when
you specifically need to see console output.

## Updating from now on

This is the one version you install manually into a fresh folder.

For future fixes:

1. Download the newer Evil's Media Optimizer ZIP.
2. Open the app.
3. Open **Settings → Updates**.
4. Click **Install Update from ZIP**.
5. Select the downloaded ZIP.
6. Close and reopen the app after it reports success.

The updater preserves:

- `config.json`
- Jellyfin API settings
- `history.json`
- Poster cache
- Logs
- Update backups

Before changing program files, it creates a backup under:

    _updates\backups\

## Safety

The updater only accepts a package containing `app.py`, `version.py`,
`updater.py`, and `EvilsMediaOptimizer.pyw`, and it refuses to install the
same or an older version.

from __future__ import annotations

import json
import shutil
import tempfile
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path


class UpdateError(RuntimeError):
    pass


@dataclass(frozen=True)
class UpdateResult:
    old_version: str
    new_version: str
    backup_path: Path


PRESERVE_NAMES = {
    "config.json",
    "history.json",
    "evils_media_optimizer.log",
}

PRESERVE_DIRS = {
    "cache",
    "_updates",
    "__pycache__",
}


def _version_tuple(value: str) -> tuple[int, ...]:
    try:
        return tuple(int(part) for part in value.strip().split("."))
    except ValueError as exc:
        raise UpdateError(f"Invalid version number: {value}") from exc


def _find_package_root(extracted: Path) -> Path:
    candidates = []
    for app_file in extracted.rglob("app.py"):
        parent = app_file.parent
        if (parent / "version.py").exists():
            candidates.append(parent)

    if len(candidates) != 1:
        raise UpdateError(
            "The ZIP must contain exactly one Evil's Media Optimizer "
            "application folder with app.py and version.py."
        )
    return candidates[0]


def _read_version(package_root: Path) -> str:
    namespace: dict[str, object] = {}
    version_file = package_root / "version.py"
    try:
        exec(
            version_file.read_text(encoding="utf-8"),
            namespace,
        )
    except Exception as exc:
        raise UpdateError(
            f"Could not read update version: {exc}"
        ) from exc

    value = namespace.get("APP_VERSION")
    if not isinstance(value, str) or not value.strip():
        raise UpdateError("Update package has no valid APP_VERSION.")
    return value.strip()


def _backup_application(app_dir: Path, current_version: str) -> Path:
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    backup = (
        app_dir
        / "_updates"
        / "backups"
        / f"{current_version}-{timestamp}"
    )
    backup.mkdir(parents=True, exist_ok=False)

    for item in app_dir.iterdir():
        if item.name in PRESERVE_NAMES:
            continue
        if item.name in PRESERVE_DIRS:
            continue

        destination = backup / item.name
        if item.is_dir():
            shutil.copytree(item, destination)
        else:
            shutil.copy2(item, destination)

    return backup


def _copy_update(package_root: Path, app_dir: Path) -> None:
    for item in package_root.iterdir():
        if item.name in PRESERVE_NAMES:
            continue
        if item.name in {"cache", "_updates", "__pycache__"}:
            continue

        destination = app_dir / item.name

        if item.is_dir():
            if destination.exists():
                shutil.rmtree(destination)
            shutil.copytree(item, destination)
        else:
            shutil.copy2(item, destination)


def install_update_zip(
    update_zip: Path,
    app_dir: Path,
    *,
    current_version: str,
) -> UpdateResult:
    update_zip = update_zip.resolve()
    app_dir = app_dir.resolve()

    if not update_zip.exists():
        raise UpdateError(f"Update ZIP not found: {update_zip}")
    if update_zip.suffix.lower() != ".zip":
        raise UpdateError("The selected update must be a ZIP file.")
    if not zipfile.is_zipfile(update_zip):
        raise UpdateError("The selected file is not a valid ZIP archive.")

    with tempfile.TemporaryDirectory(
        prefix="evils-media-update-"
    ) as temporary:
        extracted = Path(temporary)
        try:
            with zipfile.ZipFile(update_zip, "r") as archive:
                archive.extractall(extracted)
        except Exception as exc:
            raise UpdateError(
                f"Could not extract the update: {exc}"
            ) from exc

        package_root = _find_package_root(extracted)
        new_version = _read_version(package_root)

        if _version_tuple(new_version) <= _version_tuple(current_version):
            raise UpdateError(
                f"This package is version {new_version}. "
                f"Installed version is {current_version}. "
                "Choose a newer update package."
            )

        # Basic safety checks before modifying the current installation.
        required = [
            "app.py",
            "version.py",
            "updater.py",
            "EvilsMediaOptimizer.pyw",
        ]
        missing = [
            name
            for name in required
            if not (package_root / name).exists()
        ]
        if missing:
            raise UpdateError(
                "Update package is incomplete. Missing: "
                + ", ".join(missing)
            )

        backup = _backup_application(
            app_dir,
            current_version,
        )

        try:
            _copy_update(package_root, app_dir)
        except Exception as exc:
            raise UpdateError(
                "The update could not be copied. "
                f"A backup was created at {backup}. Error: {exc}"
            ) from exc

    return UpdateResult(
        old_version=current_version,
        new_version=new_version,
        backup_path=backup,
    )

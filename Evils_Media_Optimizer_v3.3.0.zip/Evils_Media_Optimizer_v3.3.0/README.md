# Evil's Media Optimizer 3.3.0

Install from version 3.2.0 using Settings → Updates.

New:
- SCAN button uses generic wording.
- Multiple library folders, one per line in Settings → General.
- Functional Help, Settings and Updates buttons.
- UPDATE AVAILABLE detection for newer local ZIPs.
- Dashboard, Movies and Queue sidebar buttons now work.
